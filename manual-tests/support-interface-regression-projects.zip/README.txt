Support interface regression projects for OrcaSlicer PR #13912
https://github.com/OrcaSlicer/OrcaSlicer/pull/13912

Use a build containing the updated PR #13912 fix. Download instructions:
https://www.orcaslicer.com/wiki/how_to_download_pr_artifacts

Open each .3mf as a project, keep its saved settings, and slice it again.
In Preview select the Line Type color scheme. Move BOTH layer-range handles
on the right to the target height, so only one layer is visible.

Both projects deliberately use Top interface layers = 0 and Bottom interface
layers = 2. They test BOTTOM interfaces where support rests on the model.
No top interface beneath the roof is expected in these projects.

01-zero-gap.3mf
----------------
Normal automatic Grid support; 0.2 mm object layers; independent support layer
height enabled; Top Z distance = 0.2 mm; Bottom Z distance = 0 mm.

Inspect Z = 5.20 mm, above the tunnel floor. Expected: a dense Support interface
cap between the tunnel walls. There should be two bottom interface layers,
at Z = 5.20 mm and approximately 5.47 mm. The roof near Z = 15 mm is not the
inspection point. The earlier PR revision erased both bottom interface layers.

02-wall-clearance.3mf
--------------------
An inverted square pyramid on a 2 mm slab. Normal automatic Grid support;
0.2 mm object layers; independent support heights enabled; Top and Bottom Z
distance = 0.2 mm; Support/object XY distance = 0.35 mm.

Inspect Z = 2.40 mm in top view. Zoom beside the central pyramid cross-section.
Expected: Support interface extrusion stays outside the model wall with a gap.
The earlier PR revision let interface extrusion intrude into the expanding wall.
The second bottom interface layer is at Z = 2.60 mm.

These projects guard against regressions in the EARLIER implementation of
PR #13912. A released build or main may already pass these two checks; the
original missing-interface issue has its own project linked in the PR.
PR #13939 addresses a separate top-interface problem and is not required
for these two bottom-interface checks.

For useful feedback, include your OrcaSlicer build/commit, OS, project name,
layer Z height, and a single-layer Line Type screenshot. These are slicing
checks; no physical print is required. Both projects were re-sliced successfully
with the Windows Release test build containing the updated fixes.
